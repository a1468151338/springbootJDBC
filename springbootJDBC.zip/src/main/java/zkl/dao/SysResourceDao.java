package zkl.dao;

import zkl.common.dao.BaseDao;
import zkl.entity.SysResource;
import zkl.entity.SysRole;

/**
 * Created by Administrator on 2018/1/1.
 */
public interface SysResourceDao extends BaseDao<SysResource>{
}
