package zkl.dao;

import zkl.common.dao.BaseDao;
import zkl.entity.SysAttachment;
import zkl.entity.SysUser;

/**
 * Created by Administrator on 2017/12/27.
 */
public interface SysAttachmentDao extends BaseDao<SysAttachment> {

}
