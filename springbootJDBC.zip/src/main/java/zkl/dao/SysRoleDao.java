package zkl.dao;

import zkl.common.dao.BaseDao;
import zkl.common.entity.BaseEntity;
import zkl.entity.SysRole;

/**
 * Created by Administrator on 2018/1/1.
 */
public interface SysRoleDao extends BaseDao<SysRole>{
}
